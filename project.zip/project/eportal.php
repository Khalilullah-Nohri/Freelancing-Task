<!-- <?php 
session_start();
if(!isset($_SESSION["sess_user"])){
	header("location:dataBase2.php");
} else {
?> -->
<!doctype html>
<html>
<head>
<title>Welcome</title>
    <style> 
 #secondary{
     display: flex;
     flex: 2;
    justify-content: center;
    }            
        
    </style>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

</head>
<body>
    
<nav class="navbar navbar-expand-lg navbar-light bg-light">

<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo01" aria-controls="navbarTogglerDemo01" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarTogglerDemo01">
    <a class="navbar-brand"><i class="fa fa-graduation-cap" aria-hidden="true"></i></a>
    <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
      <li class="nav-item active">
        <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Assigment Upload</a>
      </li>
      <li class="nav-item">
        <a class="nav-link " href="#" tabindex="-1" >Upcoming Assignment</a>
      </li>
      <li class="nav-item">
        <a class="nav-link " href="#" tabindex="-1" >Profile Editing</a>
      </li>
    </ul>
    <form class="form-inline my-2 my-lg-0">
      <!-- <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search"> -->
      <button class="btn btn-outline-success my-2 my-sm-0" type="submit"><a href="logout.php">Logout</a></button>
    </form>
  </div>
</nav>


<div id="secondary">

<div> <img src="Images/profile.png" alt="" style="width: 200px; background-color:blue "> </div>
<div>

    
    <h2>Welcome, <?=$_SESSION['sess_user'];?>! </h2>
    <p>
        SUCCESSFULLY Login 
    </p>
    
</div>
</div>





</body>

</html>
<!-- <?php
}
?>
 -->

