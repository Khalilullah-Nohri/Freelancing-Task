<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SignUp Form</title>
    <!-- <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous"> -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <!-- <link rel="stylesheet" href="path/to/font-awesome/css/font-awesome.min.css"> -->
    <link rel="stylesheet" href="style2.css">
</head>

<body>
    <div id="header">
        <div class="secondDiv">
            <div style=" margin: 160px 0px 0px 20px; text-align: justify; font-size: 20px;">
                <p style="font-weight: bold; color: indigo;">
                    Terms And condition...
                </p>
                <br><br>
                <p style="color: white;">

                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Quae eaque deleniti libero fugiat!
                    Reiciendis
                    nostrum cupiditate distinctio aliquam repellendus voluptate quod illum architecto repellat, quasi
                    veritatis quisquam nisi fugiat quidem!
                    Lorem ipsum dolor sit, amet consectetur adipisicing elit. Magni placeat, ut dolore temporibus porro
                    voluptatum dicta cupiditate, numquam perferendis corporis, exercitationem modi recusandae. Earum
                    odio
                    sunt totam, possimus aperiam consequatur!
                </p>
            </div>
        </div>
        <div>
            <form action="dataBase.php" method="post" onsubmit="return check()" style="background-color: white; opacity: inherit; height: 100%;">
                <!-- margin: -25px 0 0 -20px -->
                <fieldset id="fieldset">
                    <legend style="margin: 0 auto;">SignUp</legend>
                    <!-- <form action="dataBase.php" method="post"> -->
                    <div>
                        <input type="text" id="fullName" name="fullName" class="inputs" value="" placeholder="Full Name" required>
                    </div>

                    <div>
                        <input type="text" id="surName" name="surName" class="inputs" placeholder="SurName">
                    </div>
                    <!-- <div style="display: flex; border: 1px solid black; flex-basis: 30px;" id="div5   ">
                        <label for="" style="flex: 1;">Gender</label>
                        <select name="gender" id="gender" style="flex: 1;">
                            <option value="male">Male
                            </option>
                            <option value="femlae">Female</option>
                            <option value="other">N?A</option>
                        </select>
                    </div> -->
                    <div>
                        <input type="text" id="designation" name="designation" class="inputs" placeholder="Designation" required>
                    </div>
                    <div>
                        <input type="email" id="emailAddress" name="emailAddress" class="inputs" placeholder="Email" required>
                    </div>
                    <div>
                        <input type="number" id="contactNumber" name="contactNumber" class="inputs" placeholder="Contact Number" required>
                    </div>
                    <div>
                        <input type="password" id="password" name="password" class="inputs" placeholder="Password" required>
                    </div>
                    <div>
                        <input type="password" id="confirmPassword" name="confirmPassword" class="inputs" placeholder="Confirm Password" required>
                        <p style="color: red;" id="doesnotMatch"></p>
                    </div>
                    <div>
                        <input type="text" id="address" name="address" placeholder="Address" class="inputs">
                    </div>
                    <br>
                    <div style="display: flex; justify-content: space-between;">

                        <input type="submit" id="button" value="Sign Up" onclick="check()">
                        <!-- <button id="button" onclick="check()"> Sign Up</button> -->
                        <button id="button2">
                            <a href="index.html" style="text-decoration: none; color: black;">
                                Back To Login pages
                                <i class="fa fa-long-arrow-right" aria-hidden="true"></i>

                            </a>
                        </button>
                    </div>
                    <!-- <button type="button" class="btn btn-success">Success</button> -->
                    <!-- </form> -->
                </fieldset>
            </form>
        </div>
    </div>
</body>
<script>
    function check() {

        var fullName = document.getElementById('fullName').value;
        var designation = document.getElementById('designation').value;
        var email = document.getElementById('emailAddress').value;
        var number = document.getElementById('contactNumber').value;
        var password = document.getElementById('password').value;
        var confirmPassword = document.getElementById('confirmPassword').value;

        if (fullName == '' || designation == '' || email == '' || number == '' || password == '')
            alert('Must Fill The mandatory Field')
        // window.location.href="index.html"
        else {

            if (password != confirmPassword) {
                document.getElementById('doesnotMatch').innerHTML = "Password Doesn't MAtch"
                return false
            }
            

            else {
                // alert ('Successed')
                // onsubmit (this, true)
                document.getElementById('para').innerHTML = "Successfully Created"
                // window.location.href='index.html'
            }

        } // outer else end
    } // method end
</script>

</html>