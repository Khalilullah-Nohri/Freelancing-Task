-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 10, 2020 at 10:46 PM
-- Server version: 10.4.13-MariaDB
-- PHP Version: 7.4.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `lmsystem`
--

-- --------------------------------------------------------

--
-- Table structure for table `managment`
--

CREATE TABLE `managment` (
  `S No` int(11) NOT NULL,
  `FullName` text NOT NULL,
  `Caste` text NOT NULL,
  `Designation` text NOT NULL,
  `Email` text NOT NULL,
  `ContactNumber` int(11) NOT NULL,
  `Password` text NOT NULL,
  `Address` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `managment`
--

INSERT INTO `managment` (`S No`, `FullName`, `Caste`, `Designation`, `Email`, `ContactNumber`, `Password`, `Address`) VALUES
(1, 'K', 'Nohri', 'designation', 'khalilnohri666@gmail.com', 0, '00000000', 'Mithi'),
(2, 'Shahbaz', 'Nohri', 'designation', 'shahbaz@gmail.com', 0, '0000', 'Mithi'),
(3, 'Shahbaz', 'Nohri', 'student', 'shahbaz@gmail.com', 0, '0000', 'Mithi'),
(4, 'Kamran', 'Mirani', 'Student', 'kamran@gmail.com', 0, '1111', 'Sukkur'),
(5, '', '', '', '', 0, '', ''),
(6, '', '', '', '', 0, '000', ''),
(7, 'Khalilullah', 'Nohri', 'Student', 'khalilnohri@gmail.com', 2147483647, '90', 'Mithi'),
(8, 'Arbab', 'Nohri', 'Student', 'arbab@xyz.com', 23421, '0909', 'Mithi'),
(9, 'Zeeshan', 'Khaskheli', 'Student', 'zeeshan@twitter.com', 203030330, 'ZK', 'Badin'),
(10, 'Zeeshan', 'Khaskheli', 'Student', 'zeeshan@twitter.com', 203030330, 'asa', 'Badin'),
(11, 'Sher', 'Dahri', 'Student', 'sher@gmail.com', 2147483647, 'smd', 'Hala'),
(12, 'Adil', 'Halepota', 'Student', 'adil@muet.edu.pk', 2147483647, 'bachalTheGreat', 'Tando'),
(13, 'Adil', 'Halepota', 'Student', 'adil@muet.edu.pk', 2147483647, 'asasa', 'Tando'),
(14, 'Unknown', 'Unknown', 'Unknown', 'Unknown@Unknown.com', 0, 'Unknown', 'Unknown'),
(15, 'Khalilullah', '', 'Teacher', 'khalilnohri666@gmail.com', 2147483647, 'asas', 'Thar'),
(16, '', '', '', '', 0, '', ''),
(17, '', '', '', '', 0, '', ''),
(18, '', '', '', '', 0, '', ''),
(19, '', '', '', '', 0, '', ''),
(20, '', '', '', '', 0, '', ''),
(21, '', '', '', '', 0, '', ''),
(22, '', '', '', '', 0, '', ''),
(23, '', '', '', '', 0, '', ''),
(24, '', '', '', '', 0, '', ''),
(25, '', '', '', '', 0, '', ''),
(26, '', '', '', '', 0, '', ''),
(27, '', '', '', '', 0, '', ''),
(28, '', '', '', '', 0, '', ''),
(29, '', '', '', '', 0, '', ''),
(30, '', '', '', '', 0, '', ''),
(31, '', '', '', '', 0, '', ''),
(32, '', '', '', '', 0, '', ''),
(33, '', '', '', '', 0, '', ''),
(34, 'Kamran', 'Mirani', 'Student', 'kamran@fb.com', 90909090, 'KS', ''),
(35, 'Kamran', 'Mirani', 'Student', 'kamran@fb.com', 909090909, 'Kami', ''),
(36, 'Khalilullah', 'Nohri', 'Student', 'khalilnohri666@gmail.com', 90909090, 'qqq', ''),
(37, 'Khalilullah', 'Nohri', 'Student', 'khalilnohri666@gmail.com', 90909090, 'aaaa', ''),
(38, 'Unknown', 'Unknown', 'Unknown', 'khalilnohri666@gmail.co', 2147483647, 'pass', ''),
(39, 'K', 'K', 'Teacher', 'k@a.com', 90909, '9090', ''),
(40, 'Khalilullah', 'Nohri', 'Student', 'k@gmail.com', 2147483647, 'para', 'Thar'),
(41, 'Arsalan', '', 'Student', 'arsalan@gmail.com', 303030330, 'arsalan', ''),
(42, 'Hamza', 'Yousafzai', 'Student', 'hamza@gmail.com', 2022020, 'pass', 'HYD'),
(43, 'Khalilullah', '', 'Student', 'khalilnohri3@fb.com', 2147483647, 'KN', ''),
(44, 'Unknown', '', 'Teacher', 'teacher@fb.com', 90909, '90', ''),
(45, 'Zeeshan', 'Khaskheli', 'Student', 'zk@gmail.com', 202020202, 'ZK', ''),
(46, 'Final', '', 'Student', 'final@final.com', 2147483647, 'asas', ''),
(47, 'Khalilullah', 'Nohri', 'Student', 'khalilnohri666@twitter.com', 2147483647, 'knohri', 'Thar'),
(48, 'Khalil', 'Nohri', 'Student', 'khalilnohri66@gmail.com', 2147483647, 'pass', 'Thar'),
(49, 'Sher Muhammad', 'Dahri', 'Student', 'shermd@gmail.com', 300030303, 'pass', 'Hala');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `managment`
--
ALTER TABLE `managment`
  ADD PRIMARY KEY (`S No`),
  ADD UNIQUE KEY `S No` (`S No`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `managment`
--
ALTER TABLE `managment`
  MODIFY `S No` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
