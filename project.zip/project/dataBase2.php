<?php

if (isset($_POST["submit"])) {

    if (!empty($_POST['emailInput']) && !empty($_POST['passwordInput'])) {
        $user2 = $_POST['emailInput'];
        $pass2 = $_POST['passwordInput'];

        extract($_POST);
        include("connectivity.php");

        $query = mysqli_query($conn, "SELECT * FROM managment WHERE Email='" . $user2 . "' AND Password='" . $pass2 . "'");
        $numrows = mysqli_num_rows($query);

        if (($numrows) != 0) {
            while ($row = mysqli_fetch_assoc($query)) {
                $dbusername = $row['Email'];
                $dbpassword = $row['Password'];
                $userName = $row['FullName'];
                $userSurname= $row['Caste'];
            }

            if ($user2 == $dbusername && $pass2 == $dbpassword) {
                session_start();  
                $_SESSION['sess_user']=$userName;  
                // /* Redirect browser */  
                // header("Location: member.php");  
                header('Location: eportal.php');
                echo $des;
            }
        }
         else {
           echo ('Invalid username or password!');
            // session_start();
            // $_SESSION['sess_user']=$dbusername;  

            // // /* Redirect browser */  
            // header("Location: eportal.php");

            // $msg=$_REQUEST['passwordInput'];
        }
        // if connectivity success
    } //inner if (email and password are given)
    else {
        echo "All fields are required!";
    }
} //outer if
?>