<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Online Task Submission </title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <!-- <link rel="stylesheet" href="signUp.html"> -->

<link rel="stylesheet" href="script.js">


</head>

<body>

    <div class="header" style="background-image: url(https://cdn.hipwallpaper.com/i/62/26/HKoPzd.jpg)">

        <form action="dataBase2.php" method="post" class="form">
            <h1>Login</h1>

            <div class="input">
                <p style="color: green;" id="para">  </p>
                <input type="text" name="emailInput" id="email" placeholder="Type Your Email" required>
            </div>
            <div class="input">
                <!-- <i class="fa fa-user-circle" aria-hidden="true"></i> -->
                <input type="password" name="passwordInput" id="password" placeholder="Type Your Password" required>
            </div>


            <div class="forget">
                <a href="#">
                    Forgot password ?

                </a>
            </div>
            <div class="loginButton">
                <input type="submit" value="Login" class="login" name="submit">
                <!-- <button class="login" name="submit" onclick="login()" >Login</button> -->
                <button class="signUp"><a href="signUp.php" > SignUp</a></button>
            </div>
            <div class="othersMedia">
                <p>Or you can join with</p>
                <span>
                    <i class="fa fa-facebook-official" id="icon" aria-hidden="true"></i>
                    <i class="fa fa-google" id="icon2" aria-hidden="true"></i>
                </span>
            </div>
            <div>
                <button > <a href="admin.php" style="text-decoration: none; color:black"> Admin Portal</a></button>
            </div>
        </form>

    </div>





</body>



</html>