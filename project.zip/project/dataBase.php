<?php


// $host = 'localhost';
// $user = 'root';
// $pass = '';
// $dbname = 'lmsystem';

// $conn = mysqli_connect($host, $user, $pass, $dbname);
// if (!$conn)
//     die('Could not connect: ' . mysqli_error($conn));

// else {

    extract($_POST);
    include("connectivity.php");
    // Databse Creation

    // $sql = "CREATE Database  newDB";      
    // if(mysqli_query( $conn,$sql)){  
    //     echo "Database newDB created successfully.";  
    //     }
    //     else{  
    //         echo "Sorry, database creation failed ".mysqli_error($conn);  
    //         } 

    // Table Creaete
    // $sql = "create table db(Cnic varchar(14) NOT NULL,name VARCHAR(20) NOT NULL,SurName VARCHAR(20) NOT NULL,  
    //             age INT NOT NULL,WhatsappN INT NOT NULL,address VARCHAR(20) NOT NULL, primary key (Cnic))";

    // if (mysqli_query($conn, $sql)) {
    //     echo "Table emp5 created successfully <br>";

    $primaryEmail = $_POST['emailAddress'];
    $query = mysqli_query($conn, "SELECT * FROM managment WHERE Email='" . $primaryEmail . "' ");
    $numrows = mysqli_num_rows($query);

    if (($numrows) != 0) {
        while ($row = mysqli_fetch_assoc($query)) {
            $dbuserEmail = $row['Email'];
        }

        if ($primaryEmail == $dbuserEmail ) {
         echo 'Already Exist';
        }
       
    }
    else
    {
    // Insertion
    $fullName       = $_POST['fullName'     ];
    $surName        = $_POST['surName'      ];
    $designation    = $_POST['designation'  ];
    $emailAddress   = $_POST['emailAddress' ];
    $contactNumber  = $_POST['contactNumber'];
    $password       = $_POST['password'     ];
    $address        = $_POST['address'      ]; 

    $sql = "INSERT INTO managment(FullName, Caste ,Designation,Email,ContactNumber,Password,Address) 
                        VALUES ('$fullName','$surName','$designation','$emailAddress','$contactNumber','$password','$address')";

    if (mysqli_query($conn, $sql)) {
        // echo "Record inserted successfully";

        $_SESSION['sess_user']="Record inserted successfully";  

        // /* Redirect browser */  
        header("Location: index.php");

    } else {
        echo "Could not insert record: " . mysqli_error($conn);
    }

    }






mysqli_close($conn);


?>

!



<!-- $fullName=$_POST['fullName'];
$surName=$_POST['surName'];
$designation=$_POST['designation'];
$emailAddress=$_POST['emailAddress'];
$contactNumber=$_POST['contactNumber'];
$password=$_POST['password'];
$confirmPassword=$_POST['confirmPassword'];
$address=$_POST['address'];

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "phpmyadmin";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "INSERT INTO academy(fullName,surName,designation,emailAddress,contactNumber)
VALUES ('John', 'Doe','Student', 'john@example.com','030000000')";

if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

// $conn->close();

// $conn = mysqli_connect('localhost','host','');
// if($conn->connect_error){
//     die('Connection Failed : ',$conn->connect_error);
// }
// else
// {

// $stmt="insert into academy(fullName,surName,designation,emailAddress,contactNumber,password,confirmPassword,address) 
// values('A','A','A','A','A','A','A','A')";


// $stmt->bind_param(ssssisss,$fullName,$surName,$designation,$emailAddress,$contactNumber,$password,$confirmPassword,$address);
// $stmt->execute();
// echo "Success beta";
// $stmt->close();


// if (mysqli_query($conn, $stmt)) {
//     echo "New record created successfully";
// } 
// else {
//     echo "Error: " . $stmt . "<br>" . mysqli_error($conn);
// }

// mysqli_close($conn);

// $conn->close();
// }

// $db=mysql -->